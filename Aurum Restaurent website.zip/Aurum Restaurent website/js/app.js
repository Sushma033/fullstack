// ==================== GLOBAL UI, THEME, FEATURED, REVIEWS ====================

// ----- Theme Management -----
function initTheme() {
    const savedTheme = localStorage.getItem('aurum_theme') || 'light';
    if (savedTheme === 'dark') document.body.classList.add('dark');
    const colorTheme = localStorage.getItem('aurum_color') || 'default';
    if (colorTheme === 'emerald') document.body.classList.add('theme-emerald');
    if (colorTheme === 'royal') document.body.classList.add('theme-royal');
}

function toggleTheme() {
    document.body.classList.toggle('dark');
    localStorage.setItem('aurum_theme', document.body.classList.contains('dark') ? 'dark' : 'light');
}

function setColorTheme(theme) {
    document.body.classList.remove('theme-emerald', 'theme-royal');
    if (theme !== 'default') document.body.classList.add(`theme-${theme}`);
    localStorage.setItem('aurum_color', theme);
}

function renderGlobalNavbar() {
    document.querySelectorAll('nav.navbar').forEach(nav => {
        const content = nav.innerHTML.replace(/<!--([\s\S]*?)-->/g, '').trim();
        if (!content) {
            nav.innerHTML = `
                <div class="nav-container">
                    <div class="logo"><i class="fas fa-crown"></i> Aurum Palace</div>
                    <div class="nav-links" id="navLinks">
                        <a href="index.html">Home</a>
                        <a href="menu.html">Menu</a>
                        <a href="cart.html">Cart <span id="cartCountNav" class="cart-badge">0</span></a>
                        <a href="tracking.html">Track Order</a>
                        <a href="profile.html">Profile</a>
                        <a href="#" id="themeToggleNav"><i class="fas fa-moon"></i></a>
                        <a href="#" id="logoutBtnNav" style="display:none;">Logout</a>
                        <a href="login.html" id="loginBtnNav">Login</a>
                    </div>
                    <div class="mobile-menu" id="mobileMenuBtn"><i class="fas fa-bars"></i></div>
                </div>
            `;
        }
    });
}

// ----- Featured Items (Homepage) -----
function loadFeaturedItems() {
    const menu = getMenu();
    const featured = menu.slice(0, 4);
    const grid = document.getElementById('featuredGrid');
    if (grid) {
        grid.innerHTML = featured.map(item => `
            <div class="food-card">
                <img src="${item.image}" alt="${item.name}">
                <div class="card-body">
                    <h3>${item.name}</h3>
                    <p>$${item.price.toFixed(2)}</p>
                    <button onclick="addToCart('${item.id}')" class="btn-icon">Order now</button>
                </div>
            </div>
        `).join('');
    }
}

// ----- Latest Reviews Preview -----
function displayLatestReviews() {
    const reviews = getReviews().slice(-3);
    const container = document.getElementById('latestReviews');
    if (container) {
        if (reviews.length === 0) {
            container.innerHTML = '<p>No reviews yet. Be the first to write!</p>';
            return;
        }
        container.innerHTML = reviews.map(r => `
            <div class="review-card" style="background:var(--card-bg); padding:1rem; margin:0.5rem 0; border-radius:12px;">
                <i class="fas fa-star" style="color:gold"></i> ${r.rating}/5 - "${r.comment}"<br>
                <small>— ${r.userName}</small>
            </div>
        `).join('');
    }
}

// ----- Global Navbar & Session Handling -----
document.addEventListener('DOMContentLoaded', () => {
    renderGlobalNavbar();
    initTheme();
    const user = getCurrentUser();
    const loginNav = document.getElementById('loginBtnNav');
    const logoutNav = document.getElementById('logoutBtnNav');
    
    if (user) {
        if (loginNav) loginNav.style.display = 'none';
        if (logoutNav) {
            logoutNav.style.display = 'inline-block';
            logoutNav.onclick = (e) => { e.preventDefault(); logout(); };
        }
        // Admin guard
        if (window.location.pathname.includes('admin.html') && user.role !== 'admin') {
            window.location.href = 'index.html';
        }
    } else {
        if (loginNav) loginNav.style.display = 'inline-block';
        if (logoutNav) logoutNav.style.display = 'none';
        // Protect pages that require login
        const protectedPages = ['profile.html', 'checkout.html', 'cart.html', 'admin.html'];
        if (protectedPages.some(page => window.location.pathname.includes(page))) {
            window.location.href = 'login.html';
        }
    }
    
    updateCartBadge();
    
    // Theme toggle button
    const themeToggle = document.getElementById('themeToggleNav');
    if (themeToggle) {
        themeToggle.addEventListener('click', (e) => {
            e.preventDefault();
            toggleTheme();
        });
    }
    
    // Mobile menu toggle (basic)
    const mobileBtn = document.getElementById('mobileMenuBtn');
    const navLinks = document.getElementById('navLinks');
    if (mobileBtn && navLinks) {
        mobileBtn.addEventListener('click', () => {
            if (navLinks.style.display === 'flex') navLinks.style.display = 'none';
            else navLinks.style.display = 'flex';
        });
    }
});

// Expose global functions for inline onclick usage
window.addToCart = addToCart;
window.removeCartItem = removeCartItem;
window.updateQuantity = updateQuantity;
window.toggleFavorite = toggleFavorite;
window.renderMenu = renderMenu;
window.loadFeaturedItems = loadFeaturedItems;
window.displayLatestReviews = displayLatestReviews;
window.updateCartBadge = updateCartBadge;
window.toggleTheme = toggleTheme;
window.setColorTheme = setColorTheme;
window.logout = logout;
window.createOrder = createOrder; // for checkout page
window.getCurrentUser = getCurrentUser;
window.updateOrderStatus = updateOrderStatus; // for admin
window.addMenuItem = addMenuItem;
window.getAllUsersList = getAllUsersList;