// ==================== CART OPERATIONS ====================
function addToCart(itemId, quantity = 1) {
    const user = getCurrentUser();
    if (!user) { alert('Please login first'); window.location.href = 'login.html'; return false; }
    const menu = getMenu();
    const item = menu.find(i => i.id === itemId);
    if (!item) return false;
    let cart = getCart(user.id);
    const existing = cart.find(i => i.id === itemId);
    if (existing) existing.quantity += quantity;
    else cart.push({ id: item.id, name: item.name, price: item.price, image: item.image, quantity });
    saveCart(user.id, cart);
    updateCartBadge();
    return true;
}

function updateCartBadge() {
    const user = getCurrentUser();
    if (!user) return;
    const cart = getCart(user.id);
    const totalQ = cart.reduce((sum, i) => sum + i.quantity, 0);
    document.querySelectorAll('#cartCountNav').forEach(el => { if (el) el.innerText = totalQ; });
}

function removeCartItem(itemId) {
    const user = getCurrentUser();
    let cart = getCart(user.id);
    cart = cart.filter(i => i.id !== itemId);
    saveCart(user.id, cart);
    updateCartBadge();
    if (window.location.pathname.includes('cart.html')) location.reload();
}

function updateQuantity(itemId, delta) {
    const user = getCurrentUser();
    let cart = getCart(user.id);
    const idx = cart.findIndex(i => i.id === itemId);
    if (idx !== -1) {
        cart[idx].quantity += delta;
        if (cart[idx].quantity <= 0) cart.splice(idx, 1);
        saveCart(user.id, cart);
        updateCartBadge();
        if (window.location.pathname.includes('cart.html')) location.reload();
    }
}

function getCartTotal(cartItems) {
    return cartItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);
}