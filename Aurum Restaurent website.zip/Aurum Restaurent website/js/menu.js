// ==================== MENU RENDERING & FAVORITES ====================
function renderMenu(filters = { category: 'all', veg: 'all', search: '' }) {
    let items = getMenu();
    if (filters.category !== 'all') items = items.filter(i => i.category === filters.category);
    if (filters.veg !== 'all') {
        items = filters.veg === 'veg' ? items.filter(i => i.veg === true) : items.filter(i => i.veg === false);
    }
    if (filters.search) items = items.filter(i => i.name.toLowerCase().includes(filters.search.toLowerCase()));
    
    const container = document.getElementById('menuContainer');
    if (!container) return;
    const user = getCurrentUser();
    let favs = user ? getFavorites(user.id) : [];
    
    container.innerHTML = items.map(item => `
        <div class="food-card">
            <img src="${item.image}" alt="${item.name}">
            <div class="card-body">
                <h3 class="card-title">${item.name} ${item.veg ? '<i class="fas fa-leaf" style="color:green"></i>' : '<i class="fas fa-drumstick-bite"></i>'}</h3>
                <p class="price">$${item.price.toFixed(2)}</p>
                <button class="btn-icon" onclick="addToCart('${item.id}')"><i class="fas fa-cart-plus"></i> Add</button>
                <button class="btn-icon" onclick="toggleFavorite('${item.id}')">
                    <i class="fas fa-heart" style="color:${favs.includes(item.id) ? '#e74c3c' : 'gray'}"></i>
                </button>
            </div>
        </div>
    `).join('');
}

function toggleFavorite(itemId) {
    const user = getCurrentUser();
    if (!user) { alert('Login first'); return; }
    let favs = getFavorites(user.id);
    if (favs.includes(itemId)) favs = favs.filter(id => id !== itemId);
    else favs.push(itemId);
    saveFavorites(user.id, favs);
    // Re-render menu with current filters (if on menu page)
    if (document.getElementById('categoryFilter')) {
        renderMenu({
            category: document.getElementById('categoryFilter').value,
            veg: document.getElementById('vegFilter').value,
            search: document.getElementById('searchInput').value
        });
    } else {
        // If on profile page, we might refresh later
        if (window.location.pathname.includes('profile.html')) location.reload();
    }
}