// ==================== STORAGE KEYS & INITIAL DATA ====================
const STORAGE_KEYS = {
    USERS: 'aurum_users',
    MENU: 'aurum_menu',
    CART: 'aurum_cart',
    ORDERS: 'aurum_orders',
    FAVORITES: 'aurum_favorites',
    REVIEWS: 'aurum_reviews',
    COUPONS: 'aurum_coupons'
};

// Initialize default data if localStorage is empty
function initStorage() {
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
        const defaultUsers = [
            { id: 'admin1', name: 'Admin Royale', email: 'admin@aurum.com', password: 'admin123', phone: '9999999999', address: 'Palace Road', role: 'admin', points: 100 },
            { id: 'user1', name: 'John Doe', email: 'john@example.com', password: 'user123', phone: '8888888888', address: 'Guest Lane', role: 'user', points: 50 }
        ];
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(defaultUsers));
    }
    if (!localStorage.getItem(STORAGE_KEYS.MENU)) {
        const sampleMenu = [
            { id: 'm1', name: 'Butter Chicken', category: 'main', price: 18.99, veg: false, image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=80', rating: 4.8 },
            { id: 'm2', name: 'Paneer Tikka', category: 'appetizer', price: 12.99, veg: true, image: 'https://images.unsplash.com/photo-1564758866815-4e3e576df825?auto=format&fit=crop&w=800&q=80', rating: 4.6 },
            { id: 'm3', name: 'Biryani', category: 'main', price: 15.99, veg: false, image: 'https://images.unsplash.com/photo-1627308595229-7830a5c91f9f?auto=format&fit=crop&w=800&q=80', rating: 4.9 },
            { id: 'm4', name: 'Gulab Jamun', category: 'dessert', price: 5.99, veg: true, image: 'https://images.unsplash.com/photo-1585039412915-e4ada5f3ef1a?auto=format&fit=crop&w=800&q=80', rating: 4.7 }
        ];
        localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(sampleMenu));
    }
    if (!localStorage.getItem(STORAGE_KEYS.REVIEWS)) localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify([]));
    if (!localStorage.getItem(STORAGE_KEYS.FAVORITES)) localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify({}));
    if (!localStorage.getItem(STORAGE_KEYS.COUPONS)) {
        localStorage.setItem(STORAGE_KEYS.COUPONS, JSON.stringify({ 
            "WELCOME10": { discount: 10, type: "percent" }, 
            "ROYAL5": { discount: 5, type: "fixed" } 
        }));
    }
}
initStorage();

// -------------------- Generic Getters/Setters --------------------
function getUsers() { return JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS)); }
function saveUsers(users) { localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users)); }

function getMenu() { return JSON.parse(localStorage.getItem(STORAGE_KEYS.MENU)); }
function saveMenu(menu) { localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(menu)); }

function getCart(userId) {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEYS.CART) || '{}');
    return all[userId] || [];
}
function saveCart(userId, cart) {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEYS.CART) || '{}');
    all[userId] = cart;
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(all));
}

function getOrders() { return JSON.parse(localStorage.getItem(STORAGE_KEYS.ORDERS) || '[]'); }
function saveOrders(orders) { localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders)); }

function getFavorites(userId) {
    const fav = JSON.parse(localStorage.getItem(STORAGE_KEYS.FAVORITES) || '{}');
    return fav[userId] || [];
}
function saveFavorites(userId, favList) {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEYS.FAVORITES) || '{}');
    all[userId] = favList;
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(all));
}

function getReviews() { return JSON.parse(localStorage.getItem(STORAGE_KEYS.REVIEWS) || '[]'); }
function addReview(review) {
    const revs = getReviews();
    revs.push(review);
    localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(revs));
}