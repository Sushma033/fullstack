// ==================== AUTHENTICATION ====================
function getCurrentUser() {
    const userJson = sessionStorage.getItem('aurum_session');
    return userJson ? JSON.parse(userJson) : null;
}

function setSession(user) {
    sessionStorage.setItem('aurum_session', JSON.stringify(user));
}

function logout() {
    sessionStorage.removeItem('aurum_session');
    window.location.href = 'login.html';
}

function registerUser(name, email, password, phone, address) {
    let users = getUsers();
    if (users.find(u => u.email === email)) return { success: false, msg: 'Email already exists' };
    const newId = 'u' + Date.now();
    const newUser = { id: newId, name, email, password, phone, address, role: 'user', points: 0 };
    users.push(newUser);
    saveUsers(users);
    return { success: true, user: newUser };
}

function loginUser(email, password) {
    const users = getUsers();
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
        setSession({ 
            id: user.id, name: user.name, email: user.email, 
            role: user.role, points: user.points, phone: user.phone, 
            address: user.address 
        });
        return { success: true, role: user.role };
    }
    return { success: false };
}