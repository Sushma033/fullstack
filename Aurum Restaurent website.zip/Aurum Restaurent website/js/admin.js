// ==================== ADMIN FUNCTIONS ====================
function isAdmin() {
    const user = getCurrentUser();
    return user && user.role === 'admin';
}

function getAllUsersList() {
    return getUsers();
}

function updateOrderStatus(orderId, newStatus) {
    let orders = getOrders();
    const idx = orders.findIndex(o => o.id === orderId);
    if (idx !== -1) {
        orders[idx].status = newStatus;
        saveOrders(orders);
        return true;
    }
    return false;
}

function addMenuItem(item) {
    const menu = getMenu();
    const newItem = { ...item, id: 'm' + Date.now() };
    menu.push(newItem);
    saveMenu(menu);
    return newItem;
}

function updateMenuItem(itemId, updated) {
    let menu = getMenu();
    const idx = menu.findIndex(i => i.id === itemId);
    if (idx !== -1) {
        menu[idx] = { ...menu[idx], ...updated };
        saveMenu(menu);
        return true;
    }
    return false;
}