// ==================== ORDER & PAYMENT ====================
async function createOrder(paymentMethod, couponCode = null, pointsRedeem = 0) {
    return new Promise((resolve) => {
        const user = getCurrentUser();
        if (!user) { alert('Login needed'); resolve(false); return; }
        let cart = getCart(user.id);
        if (cart.length === 0) { alert('Cart empty'); resolve(false); return; }
        
        let subtotal = cart.reduce((sum, i) => sum + (i.price * i.quantity), 0);
        let discount = 0;
        const coupons = JSON.parse(localStorage.getItem(STORAGE_KEYS.COUPONS) || '{}');
        if (couponCode && coupons[couponCode]) {
            if (coupons[couponCode].type === 'percent') discount = (subtotal * coupons[couponCode].discount) / 100;
            else discount = coupons[couponCode].discount;
        }
        
        let pointsDiscount = 0;
        let userData = getUsers().find(u => u.id === user.id);
        if (pointsRedeem > 0 && userData.points >= pointsRedeem) {
            pointsDiscount = Math.min(pointsRedeem, subtotal - discount);
            userData.points -= pointsRedeem;
            saveUsers(getUsers().map(u => u.id === user.id ? userData : u));
            user.points = userData.points;
            setSession(user);
        }
        const total = Math.max(0, subtotal - discount - pointsDiscount);
        
        // Simulate payment processing (80% success)
        setTimeout(() => {
            const success = Math.random() > 0.2;
            if (success) {
                const orders = getOrders();
                const newOrder = {
                    id: 'ord_' + Date.now(),
                    userId: user.id,
                    items: [...cart],
                    subtotal, discount: discount + pointsDiscount, total,
                    status: 'placed',
                    timestamp: new Date().toISOString(),
                    paymentMethod
                };
                orders.push(newOrder);
                saveOrders(orders);
                // Add loyalty points (5 points per order)
                userData = getUsers().find(u => u.id === user.id);
                userData.points += 5;
                saveUsers(getUsers().map(u => u.id === user.id ? userData : u));
                user.points = userData.points;
                setSession(user);
                // Clear cart
                saveCart(user.id, []);
                updateCartBadge();
                resolve(true);
            } else {
                resolve(false);
            }
        }, 1500);
    });
}

function getUserOrders(userId) {
    return getOrders().filter(o => o.userId === userId);
}